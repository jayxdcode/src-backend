// background.js

browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "makeFetchRequest") {
    const { url, init } = message;

    // Reconstruct Headers object if sent as a plain object
    if (init && init.headers && typeof init.headers === 'object' && !(init.headers instanceof Headers)) {
      init.headers = new Headers(init.headers);
    }

    // Use fetch in the background script
    return fetch(url, init)
      .then(async response => {
        // Clone to read body
        const cloned = response.clone();
        const contentType = response.headers.get('content-type') || '';

        // Always read as text for standardized responseText
        const textBody = await cloned.text();

        // Build raw headers string
        let headerLines = [];
        for (let [key, val] of response.headers.entries()) {
          headerLines.push(`${key}: ${val}`);
        }
        const responseHeaders = headerLines.join('\r\n');

        // Standard GM-like response shape
        return {
          ok: response.ok,
          status: response.status,
          statusText: response.statusText,
          responseText: textBody,
          responseHeaders,      // raw header string
          finalUrl: response.url
        };
      })
      .catch(error => {
        console.error("Background fetch error:", error);
        return {
          ok: false,
          status: 0,
          statusText: error.message || "Fetch failed",
          responseText: null,
          responseHeaders: '',
          finalUrl: url,
          error: { message: error.message, stack: error.stack }
        };
      });
  }
});